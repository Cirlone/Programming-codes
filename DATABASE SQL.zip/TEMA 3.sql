USE books
CREATE TABLE branch (
number_employees int,
locatie varchar(200),
numeee varchar(200),
);
CREATE TABLE publisher (
nume varchar(200),
);
CREATE TABLE author (
 author_name varchar(200),
 age int,
 birthplace  varchar(200),
);
CREATE TABLE book (
 pages int,
 genre varchar(200),
 title varchar(200),
 paperback bit,
);
CREATE TABLE wrote (
idk int,
);
CREATE TABLE inventory (
 nr int,
);
INSERT INTO branch(number_employees,locatie,numeee)VALUES
 (21,'centru','shaorma srl');
 INSERT INTO branch(number_employees,locatie,numeee)VALUES
 (5,'craiovita','bibliotek');
 INSERT INTO branch(number_employees,locatie,numeee)VALUES
 (111,'central_park','NYPaper');
 INSERT INTO branch(number_employees,locatie,numeee)VALUES
 (15,'outskirts','plsbuy');
 INSERT INTO branch(number_employees,locatie,numeee)VALUES
 (12512,'empirestatebuilding','workskingdom');
 INSERT INTO publisher(nume)VALUES
 ('firmaCartiX');
 INSERT INTO publisher(nume)VALUES
 ('firmaCartiY');
 INSERT INTO publisher(nume)VALUES
 ('firmaCartiZ');
 INSERT INTO publisher(nume)VALUES
 ('firmaCartiA');
 INSERT INTO publisher(nume)VALUES
 ('firmaCartiB');
 INSERT INTO author(author_name,age,birthplace)VALUES
 ('Cirla',22,'Craiova');
  INSERT INTO author(author_name,age,birthplace)VALUES
 ('Laurentiu',52,'BaiaMare');
  INSERT INTO author(author_name,age,birthplace)VALUES
 ('Obama',61,'California');
  INSERT INTO author(author_name,age,birthplace)VALUES
 ('MuhamaduBuhari',48,'Nigeria');
  INSERT INTO author(author_name,age,birthplace)VALUES
 ('DalaiLama',76,'Tibet');
  INSERT INTO book(pages,genre,title,paperback)VALUES
 (291,'Comedy','MobyDick',1);
   INSERT INTO book(pages,genre,title,paperback)VALUES
 (3191,'drama','ANightInCraiova',1);
   INSERT INTO book(pages,genre,title,paperback)VALUES
 (51,'Novela','TheBoy',0);
   INSERT INTO book(pages,genre,title,paperback)VALUES
 (221,'Sci-fi','ET-enoriasulTantalau',1);
   INSERT INTO book(pages,genre,title,paperback)VALUES
 (121,'Thriller','CirlasBrain',0);
  INSERT INTO inventory(nume)VALUES
 (21);
   INSERT INTO inventory(nume)VALUES
 (2121);
   INSERT INTO inventory(nume)VALUES
 (15621);
   INSERT INTO inventory(nume)VALUES
 (251);
   INSERT INTO inventory(nume)VALUES
 (1356121);